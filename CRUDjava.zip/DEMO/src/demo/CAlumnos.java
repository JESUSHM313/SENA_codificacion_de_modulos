/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demo;


/**
 *
 * @author jesus
 */

import java.sql.*;
import java.sql.CallableStatement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.text.*;
import java.util.*;


public class CAlumnos {
    int codigo;
    String nombrealumnos;
    String apellidosalumnos;
    

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombrealumnos() {
        return nombrealumnos;
    }

    public void setNombrealumnos(String nombrealumnos) {
        this.nombrealumnos = nombrealumnos;
    }

    public String getApellidosalumnos() {
        return apellidosalumnos;
    }

    public void setApellidosalumnos(String apellidosalumnos) {
        this.apellidosalumnos = apellidosalumnos;
    }
    
    public void InsertarAlumno(JTextField paramNombres, JTextField paramApellidos){
        
        setNombrealumnos(paramNombres.getText());
        setApellidosalumnos(paramApellidos.getText());
        
        CConexion objetoConexion= new CConexion();
        
        String consulta=("INSERT INTO alumnos(nombres,apellidos) VALUE(?,?)");
        
        try{
        
            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);
            
            cs.setString(1,getNombrealumnos());
            cs.setString(2,getApellidosalumnos());
            
            cs.execute();
            
            JOptionPane.showMessageDialog(null,"Se inserto el alumno");
        } catch (Exception e){
        
            JOptionPane.showMessageDialog(null,"NO Se inserto el alumno, error: "+ e.toString());
        }
        
        
    }
    
    public void MostrarAlumnos(JTable paramTablaTotalAlumnos){ 
        
        CConexion objetoConexion = new CConexion();
        
        DefaultTableModel modelo= new DefaultTableModel();
        
        TableRowSorter<TableModel> ordenarTabla= new TableRowSorter<TableModel>(modelo);
        paramTablaTotalAlumnos.setRowSorter(ordenarTabla);
        
        String sql="";
        
        modelo.addColumn("id");
        modelo.addColumn("Nombres");
        modelo.addColumn("Apellidos");
        
        paramTablaTotalAlumnos.setModel(modelo);
        
        sql="select * from alumnos";
        String [] datos = new String[3];
        Statement st;
        
        try{
            st= objetoConexion.estableceConexion().createStatement();
            ResultSet rs= st.executeQuery(sql);
            
            while(rs.next()){
                datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                
                modelo.addRow(datos);
              
                
            
            }
            
            paramTablaTotalAlumnos.setModel(modelo);
        
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"NO Se pudo mostrar los registros: "+ e.toString());
        }
       
           
    }
    
    public void SeleccionarAlumno(JTable paramTablaAlumnos,JTextField paramId, JTextField paramNombres, JTextField paramApellidos){

        try{
            
            int fila=paramTablaAlumnos.getSelectedRow();
            
            if(fila >=0){
                paramId.setText((paramTablaAlumnos.getValueAt(fila,0).toString()));
                paramNombres.setText((paramTablaAlumnos.getValueAt(fila,1).toString()));
                paramApellidos.setText((paramTablaAlumnos.getValueAt(fila,2).toString()));
                  
                
                
                
            }
            
            else{
                JOptionPane.showMessageDialog(null, "fila no seleccionada");
                
            }
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "error de seleccion, error: "+ e.toString());
        
        } 
        
    }
    
    public void ModificarAlumnos(JTextField paramCodigo, JTextField paramNombres, JTextField paramApellidos){
    
        setCodigo(Integer.parseInt(paramCodigo.getText()));
        setNombrealumnos(paramNombres.getText());
        setApellidosalumnos(paramApellidos.getText()); 
        
        CConexion objetoConexion = new CConexion();
        
        String consulta="UPDATE alumnos set alumnos.nombres=?, alumnos.apellidos=? WHERE alumnos.id=?";
        
        try{
            CallableStatement cs= objetoConexion.estableceConexion().prepareCall(consulta);
            cs.setString(1, getNombrealumnos());
            cs.setString(2, getApellidosalumnos());
            cs.setInt(3,getCodigo());
            
            cs.execute();
            
            JOptionPane.showMessageDialog(null, "Modificacion exitosa ");
        
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "No se ha podido modificar, error: "+ e.toString());
        
        }
    }
    
    public void EliminarAlumnos(JTextField paramCodigo){
    
        setCodigo(Integer.parseInt(paramCodigo.getText()));
        CConexion objetoConexion= new CConexion();
        
        String consulta="DELETE FROM alumnos where alumnos.id=?;";
        
        try{
            CallableStatement cs= objetoConexion.estableceConexion().prepareCall(consulta);
            cs.setInt(1, getCodigo());
            
            
            
            cs.execute();
            
            JOptionPane.showMessageDialog(null, "Se ha eliminado correctamente ");
        
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "No se ha podido eliminar, error: "+ e.toString());
        
        }
        
    }




}
