/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demo;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author jesus
 */
public class CConexion {
    
    Connection conectar =null;
    String usuario = "root";
    String contrasenia = "1007454313";
    String bd ="bdescuela";
    String ip = "localhost";
    String puerto = "3306";
    
    String cadena= "jdbc:mysql://" +ip+ ":"+ puerto +"/"+bd;
    
    public Connection estableceConexion(){
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conectar = DriverManager.getConnection(cadena,usuario,contrasenia);
            JOptionPane.showMessageDialog(null,"Se ha conectado a la base de datos");
            
            
        
        }catch (HeadlessException | ClassNotFoundException | SQLException e){
            JOptionPane.showMessageDialog(null,"error al conectar a la base"+ e.toString());
            
        }
        return conectar;
        
        
        
    
    }
    
}


    

