/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package demo;

/**
 *
 * @author jesus
 */
public class inicio {
    public static void main(String[] args) {
        FormAlumno objetoFormulario = new FormAlumno();
        objetoFormulario.setVisible(true);
        
    }
    
}
